package com.day2;

public class FinalClass {

	public void content() {
		System.out.println("hello Pavan");
	}
}
