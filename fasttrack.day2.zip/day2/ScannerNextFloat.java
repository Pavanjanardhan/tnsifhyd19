package com.day2;

import java.util.Scanner;

public class ScannerNextFloat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner input=new Scanner(System.in);
		System.out.print("Give float input a: ");
		float a=input.nextFloat();
		
		System.out.println("value of a="+a);
		
		input.close();

	}

}
