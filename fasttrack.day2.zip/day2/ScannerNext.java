package com.day2;

import java.util.Scanner;

public class ScannerNext {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input=new Scanner(System.in);
		System.out.print("Give one word input s: ");
		String s=input.next();
		
		System.out.println("value of s="+s);
		
		input.close();

	}

}
