package com.day2;

public class Base {
	public void display() {
		
		System.out.println("instance method content from base class");
		
	} 
	public static String display1() {
		
		return "instance method content from base class";
	}

}
  