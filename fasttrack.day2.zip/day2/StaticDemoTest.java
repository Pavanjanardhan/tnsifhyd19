package com.day2;

public class StaticDemoTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StaticDemo.callme();
		System.out.println("value of b outise function="+StaticDemo.b);

	}

}
