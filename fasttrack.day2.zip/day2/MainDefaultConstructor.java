package com.day2;

public class MainDefaultConstructor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		DefaultConstructor dc=new DefaultConstructor();
		dc.details();
	}

}
