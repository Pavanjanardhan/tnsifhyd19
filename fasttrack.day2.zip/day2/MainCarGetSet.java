package com.day2;

public class MainCarGetSet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		CarGetSet c=new CarGetSet();
		c.setEmpName("Pavan");
		c.setAge(21);
		c.setEmpid(01);
		c.setEmpSalary(1000000);
		
		c.Employee();
	}

}
