package com.sri.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sri.demo.entity.Placement;
import com.sri.demo.repository.PlacementRepository;

@Service
public class PlacementServiceImpl implements PlacementService {

	@Autowired
	PlacementRepository placementrepository;

	@Override
	public Placement save(Placement placement) {
		// TODO Auto-generated method stub
		return placementrepository.save(placement);
	}

	@Override
	public List<Placement> fetchPlacementList() {
		// TODO Auto-generated method stub
		return placementrepository.findAll();
	}

	@Override
	public Placement fetchPlacementById(Long id) {
		// TODO Auto-generated method stub
		return placementrepository.findById(id).get();
	}

	@Override
	public void deletePlacementById(Long id) {
		placementrepository.deleteById(id);
	}
	
}
