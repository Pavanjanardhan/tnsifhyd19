package com.sri.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sri.demo.entity.Placement;
import com.sri.demo.service.PlacementService;

@RestController
public class PlacementController {

	@Autowired
	PlacementService placementservice;
	
	@PostMapping("/placements")
	public Placement savePlacement(@RequestBody Placement placement) {
    	
    	return placementservice.save(placement);
	
	}
	
	
	@GetMapping("/placements")
    public List<Placement> fetchPlacementList() {
        //LOGGER.info("Inside fetchDepartmentList of DepartmentController");
        return placementservice.fetchPlacementList();
    }
	
	
	 @GetMapping("/placements/{id}")
	    public Placement fetchPlacementById(@PathVariable("id") Long id)
	            {
	        return placementservice.fetchPlacementById(id);
	    }
	 
	 @DeleteMapping("/placements/{id}")
	    public String deletePlacementById(@PathVariable("id") Long id) {
		 placementservice.deletePlacementById(id);
	        return "Placement deleted Successfully!!";
	    }
	 
}
