package com.day4;

//Autoboxing...

public class WrapperClass {

	public static void main(String[] args) {
		int a = 10;
		double b = 5.25;
		
		Integer aObj = Integer.valueOf(a);
		Double bObj = Double.valueOf(b);
		
		if (aObj instanceof Integer) {
			System.out.println("a Object is Created.");
		}
		if (bObj instanceof Double) {
			System.out.println("b obj is created.");
		}

	}

}
