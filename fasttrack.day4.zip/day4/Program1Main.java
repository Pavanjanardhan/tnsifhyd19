package com.day4;

public class Program1Main {
	public static void main(String[] args) {
		Program1 po = new Derived();
		po.running();
	}

}
