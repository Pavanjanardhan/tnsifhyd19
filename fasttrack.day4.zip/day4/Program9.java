package com.day4;

//immutable String concept........

public class Program9 {
	public static void main(String args[]){  
		   String s="Sachin";  
		   s.concat(" Tendulkar");//concat() method insteard of +   
		   System.out.println(s);//strings are immutable objects, the output will be sachin. 
		 }  

}
