package com.day4;

public abstract class Program1 {
	abstract void running();

}
class Derived extends Program1{
	void running() {
		int a = 10;
		int b = 20*a;
		System.out.println(b);
	}
	
}

