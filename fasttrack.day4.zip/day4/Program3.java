package com.day4;

public interface Program3 {
	public void test();
}
class Dog implements Program3{
	public void test() {
		System.out.println("interface method is implemented......");
	}
	
}