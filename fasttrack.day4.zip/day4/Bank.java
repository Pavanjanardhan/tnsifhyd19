package com.day4;

public interface Bank {
	float roi ();
}
class Sbi implements Bank{
	public float roi() {
		return 9.5f;
	}
}
class Icici implements Bank{
	public float roi() {
		return 9.7f;
	}
}