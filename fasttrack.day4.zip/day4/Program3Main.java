package com.day4;

public interface Program3Main {
	public static void main(String[] args) {
		Program3 ca = new Dog();
		ca.test();
	}
}
