package com.day4;

public abstract class Shape {
	abstract double Area();
	
}
class Rectangle extends Shape{
	double Area() {
		int length = 10;
		int breadth = 20;
		int area = length*breadth;
		return area;
	}
}
class Triangle extends Shape{
	double Area() {
		int length = 10;
		int breadth = 20;
		double area =  0.5* length * breadth;
		return area;
	}
}
class Circle extends Shape{
	double Area() {
		int radius = 5;
		int area = 22/7 * radius * radius;
		return area;
		
	}
}