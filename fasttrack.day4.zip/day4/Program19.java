package com.day4;
//4) StringBuffer delete() Method

public class Program19 {
	public static void main(String args[]){  
		StringBuffer sb=new StringBuffer("Pavan");  
		sb.delete(1,3);  
		System.out.println(sb);//prints Pan  
		}  


}
