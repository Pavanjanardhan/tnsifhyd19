package com.day4;

public abstract class Program2 {
	Program2(){
		System.out.println("Parent constructor called......");
	}
	abstract void display();

}
class Abstract extends Program2{
	Abstract(){
		System.out.println("Child constructor called......");
	}
	void display() {
		char ch ='A';
		char ch1 = 'B';
		System.out.println(ch + ch1);
	}
}
