package com.day4;

public interface BankMain {
	public static void main(String[] args) {
		
	
	Bank b= new Sbi();
	Icici s = new Icici();
	System.out.println(s.roi());
	System.out.println(b.roi());
    }
}