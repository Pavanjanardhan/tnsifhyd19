package com.day4;

public class ShapeMain {

	public static void main(String[] args) {
		Rectangle r = new Rectangle();
		Triangle t = new Triangle();
		Circle c =new Circle();
		System.out.println(r.Area());
		System.out.println(t.Area());
		System.out.println(c.Area());

	}

}
