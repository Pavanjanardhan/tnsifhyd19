package com.day4;
//3) StringBuilder replace() method

public class Program23 {
	public static void main(String args[]){  
		StringBuilder sb=new StringBuilder("Hello");  
		sb.replace(1,3,"Pavan");  
		System.out.println(sb);//prints HPavanlo  
		}  


}
