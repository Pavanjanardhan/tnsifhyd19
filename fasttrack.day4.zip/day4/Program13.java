package com.day4;

//3) String compare by compareTo() method

public class Program13 {
	 public static void main(String args[]){  
		 String s1 = "Pavan";
		 String s2 = "Pavan";
		 String s3 = "Que";
		 System.out.println(s1.compareTo(s2));
		 System.out.println(s1.compareTo(s3));
		 System.out.println(s3.compareTo(s1));

	 }
}
