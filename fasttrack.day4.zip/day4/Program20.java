package com.day4;
//5) StringBuffer reverse() Method

public class Program20 {
	public static void main(String args[]){  
		StringBuffer sb=new StringBuffer("Pavan");  
		sb.reverse();  
		System.out.println(sb);//prints navaP  
		}  

}
