package com.day4;
import java.io.IOException;
public class ThrowsKeyword {
	void m() throws IOException{
		throw new IOException("Device Error");
	}
//	void n() throws IOException{
//		m();
//	}
	void p(){
		try {
			m();
		} catch (Exception e) {
			System.out.println(e+" Exception handled..");
		}
	}
	public static void main(String[] args) {
		ThrowsKeyword tk = new ThrowsKeyword();
		tk.p();
		System.out.println("Rest of code..");
	}

}
