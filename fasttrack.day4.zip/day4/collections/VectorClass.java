package com.day4.collections;
import java.util.*;
public class VectorClass {

			public static void main(String[] args) {
				try {
					Vector<Integer> al = new Vector<Integer>();
					for (int i = 1; i <= 5; i++) {
					al.add(i);
					System.out.println(al);
					}
					al.remove(3);
					System.out.println(al);
					for (int i = 1; i <= al.size(); i++) {
						System.out.println(al.get(i)+" ");
					}
				} catch (Exception e) {
					System.out.println(e);
				}
				

			}

		

	}


