package com.day4.collections;

//list
//ArrayList
//LinkedList
//vector
//stack

import java.util.*;
//import java.io.*;
public class ArrayListClass {

	public static void main(String[] args) {
		try {
			ArrayList<Integer> al = new ArrayList<Integer>();
			for (int i = 1; i <= 5; i++) {
			al.add(i);
			System.out.println(al);
			}
			al.remove(3);
			System.out.println(al);
			for (int i = 1; i <= al.size(); i++) {
				System.out.println(al.get(i)+" ");
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		

	}

}
