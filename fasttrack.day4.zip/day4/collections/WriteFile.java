package com.day4.collections;
import java.io.IOException;
import java.io.FileWriter;
public class WriteFile {
	public static void main(String[] args) {
		try {
			FileWriter fw = new FileWriter("filename.txt");
			fw.write("file in java might be tricky but its fun");
			fw.close();System.out.println("Successfully wrote the file..");
			
		} catch (IOException e) {
			System.out.println("An error occured...");
			e.printStackTrace();
		}
	

   }
}
