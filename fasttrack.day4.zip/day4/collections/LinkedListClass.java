package com.day4.collections;

import java.util.LinkedList;

public class LinkedListClass {

	public static void main(String[] args) {
		LinkedList<Integer> ll = new LinkedList<Integer>();
		for (int i = 0; i < 5; i++) {
			ll.add(i);
			System.out.println(ll);
		}
		System.out.println("after removing the value at index 2");
		ll.remove(2);
		System.out.println(ll);
		
		for (int i = 0; i < ll.size(); i++) {
			System.out.println(ll.get(i));
		}
		

	}

}
