package com.day4;

//Java String compare
//There are three ways to compare String in Java:
//By Using equals() Method
//By Using == Operator
//By compareTo() Method

//1.By Using equals() Method.

public class Program11 {
	public static void main(String args[]){  
		   String s1 = "Pavan";  
		   String s2 = "pavan";  
		   String s3 = new String("Pavan");  // by using new operator.
		   String s4 = "Janardhan";  
		   System.out.println(s1.equals(s2));//false 
		   System.out.println(s1.equals(s3));//true  
		   System.out.println(s1.equals(s4));//false  
		 }  


}
