package com.day4;

public class Program5 {
	public int roll_no;
	public String name;
	Program5(int roll_no,String name){
		this.roll_no = roll_no;
		this.name = name;
		

	}

}
