package com.day4;

//String Concatenation in Java

public class Program14 {
	public static void main(String args[]){  
		   String s="janardhan"+" pavan";  
		   System.out.println(s);
		 }  

}
