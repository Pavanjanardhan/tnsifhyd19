package com.day4;
//4) StringBuilder delete() method

public class Program24 {
	public static void main(String args[]){  
		StringBuilder sb=new StringBuilder("Janardhan");  
		sb.delete(1,3);  
		System.out.println(sb);//prints  Jardhan

		}  

}
