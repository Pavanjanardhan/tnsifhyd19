package com.day4.exceptions;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;


public class Checked_Exceptions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		File file=new File("filename.txt");
	    try {
			FileReader fr = new FileReader("filename.txt");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} //FileNotFoundException

	}

}
