package com.day4.exceptions;

public class Throw_ExceptionHandling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Throw_Exception.Validate(2);
		
		//for age less than 18
		//Exception in thread "main" java.lang.ArithmeticException: Not Valid
//		at javaday12/exception_handling.Throw_Exception.Validate(Throw_Exception.java:8)
//		at javaday12/exception_handling.Throw_ExceptionHandling.main(Throw_ExceptionHandling.java:8)

	}

}
