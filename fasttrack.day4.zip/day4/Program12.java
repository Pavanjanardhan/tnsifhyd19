package com.day4;

// By Using == operator


public class Program12 {
	public static void main(String args[]){  
		   String s1="janardhan";  
		   String s2="janardhan";  
		   String s3=new String("Janardhan");  
		   System.out.println(s1==s2);//true (because both refer to same instance)  
		   System.out.println(s1==s3);//false(because s3 refers to instance created in nonpool)  
		 }  
}
