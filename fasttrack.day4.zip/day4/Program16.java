package com.day4;

//StringBuffer()
//StringBuffer(String str)
//StringBuffer(int capacity)

//mutable..
//1) StringBuffer Class append() Method

public class Program16 {
	public static void main(String args[]){  
		StringBuffer sb=new StringBuffer("Hello ");  
		sb.append("bye");
		System.out.println(sb);
		}  


}
