package com.day4;
//2) StringBuilder insert() method

public class Program22 {
	public static void main(String args[]){  
		StringBuilder sb=new StringBuilder("Hello ");  
		sb.insert(1,"Pavan");//now original string is changed  
		System.out.println(sb);//prints   HPavanello 
		}  


}
