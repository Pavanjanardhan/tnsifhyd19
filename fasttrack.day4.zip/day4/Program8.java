package com.day4;
// Strings.......

public class Program8 {    
		public static void main(String args[]){    
		String s1="Janardhan";           //creating string by Java string literal
		char ch[]={'p','a','v','a','n'};    
		
		String s2=new String(ch);        //converting char array to string    
		
		String s3=new String("Hello"); //creating Java string by new keyword    
		System.out.println(s1);    
		System.out.println(s2);    
		System.out.println(s3);    
		}
	} 



