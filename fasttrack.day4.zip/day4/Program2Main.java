package com.day4;

public class Program2Main {
	public static void main(String[] args) {
		Abstract ab = new Abstract();
		ab.display();
	}

}
