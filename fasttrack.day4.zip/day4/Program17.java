package com.day4;

//2) StringBuffer insert() Method

public class Program17 {
	public static void main(String args[]){  
		StringBuffer sb=new StringBuffer("Pavan ");  
		sb.insert(1,"hlo");//now original string is changed  
		System.out.println(sb);//prints Phloavan  
		}  
}
