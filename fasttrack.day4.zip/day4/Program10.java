package com.day4;

public class Program10 {
	public static void main(String args[]){  
		   String s="Janardhan";  
		   s=s.concat(" Pavan");  
		   System.out.println(s);  
	}
}


