package com.day4;
//Java StringBuilder Examples
//1) StringBuilder append() method

public class Program21 {
	public static void main(String args[]){  
		StringBuilder sb=new StringBuilder("Hello ");  
		sb.append("Pavan");//now original string is changed  
		System.out.println(sb);//prints Hello Pavan 
		}  


}
