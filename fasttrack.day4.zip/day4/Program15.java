package com.day4;

//2) String Concatenation by concat() method

public class Program15 { 
	public static void main(String args[]){  
	   String s1="Janardhan ";  
	   String s2="Pavan";  
	   String s3=s1.concat(s2);  
	   System.out.println(s3);  
	  }
}
