package com.day4;
// Unboxing..

public class WrapperClass1 {

	public static void main(String[] args) {
		Integer aObj = Integer.valueOf(10);
		Double bObj = Double.valueOf(5.25);
		
		int a = aObj;
		double b = bObj;
		System.out.println(a);
		System.out.println(b);

	}

}
