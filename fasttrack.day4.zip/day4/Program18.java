package com.day4;
//3) StringBuffer replace() Method

public class Program18 {
	public static void main(String args[]){  
		StringBuffer sb=new StringBuffer("Janardhan");  
		sb.replace(1,3,"Pavan");  
		System.out.println(sb);//prints JPavanardhan  
		}  


}
