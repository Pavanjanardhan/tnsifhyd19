package com.day4;

public class Program5Main {

	public static void main(String[] args) {
		Program5[] arr = new Program5[5];
		arr[0] = new Program5(1,"Pavan");
		arr[1] = new Program5(2,"SaiGanesh");
		arr[2] = new Program5(3,"Mahesh");
		arr[3] = new Program5(4,"Keerthi");
		arr[4] = new Program5(5,"Sowmya");
		for(int i = 0;i<arr.length;i++) {
			System.out.println("Element at"+i+":"+arr[i].roll_no+" "+arr[i].name);
		}

	}

}
