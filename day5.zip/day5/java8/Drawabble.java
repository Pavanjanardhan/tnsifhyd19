package com.day5.java8;

interface Drawabble {

	void draw();
}