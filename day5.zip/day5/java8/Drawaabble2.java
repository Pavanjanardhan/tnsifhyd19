package com.day5.java8;

interface Drawaabble2 {

	String  draw(String a);
	
}
