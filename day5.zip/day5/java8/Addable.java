package com.day5.java8;

interface Addable {

	int add(int a,int b) ;
}
