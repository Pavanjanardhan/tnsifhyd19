package com.day5.java8;

public class MainDrawabble {

	public static void main(String[] args) {
		
		Drawabble id=new ImplementDrawabble();
		
		id.draw();
		

	}

}
