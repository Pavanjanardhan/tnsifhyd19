package com.day5.java8;

public class ImplementDrawabble implements Drawabble{

	public void draw() {
		
		System.out.println("I drawn Tiger");
		
	}

}
