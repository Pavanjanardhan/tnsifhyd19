//Program to demonstrate Data types
package com.day1;
public class DataTypesDemo {

	public static void main(String[] args) {

		int value1 = 101 / 61; //integer division
		float value2 = 101 / 61;
		double value3 = 10d / 6d;
		float value4 = 5/2.5f; //float division
		System.out.println("value1=" + " " + value1); 
		System.out.println("value2=" + value2);
		System.out.println("value3=" + value3);
		System.out.println("value4=" + value4);
		
		
		int marker = 512;
		//assigning expression to variable 
		double percentage = marker * 0.46f;
		System.out.println("percentage :" + percentage);
		
		
	}
}