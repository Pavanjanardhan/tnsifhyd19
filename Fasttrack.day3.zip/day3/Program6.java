package com.day3;
import java.util.Scanner;

//do-while Loop....

public class Program6 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the value of i: ");
		int i = sc.nextInt();
		do {
			System.out.println(i);
			i++;
		} while (i<10);
		sc.close();

	}

}
