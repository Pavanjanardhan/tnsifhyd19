package com.day3;
import java.util.Scanner;

//if - else-if Statement..

public class Program3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the value of num: ");
		int num = sc.nextInt();
		if (num < 0) {
			System.out.println("negative number....");
		}else if (num > 0) {
			System.out.println("Positive number....");
		}else {
			System.out.println("neither Negative nor positive number....");
		}
		sc.close();

	}

}
