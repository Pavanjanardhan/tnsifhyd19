package com.day3;

import java.util.Scanner;

//For loop....

public class Program7 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the num: ");
		int num = sc.nextInt();
		
		for(int i=1;i<=num;i++) {
			System.out.println(i);
			sc.close();
		}
		

	}

}
