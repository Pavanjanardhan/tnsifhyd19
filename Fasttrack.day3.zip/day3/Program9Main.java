package com.day3;

public class Program9Main {

	public static void main(String[] args) {
		Program9 p = new Derived();
		p.fun();

	}

}
