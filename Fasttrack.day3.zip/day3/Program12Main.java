package com.day3;

//multilevel inheritance.........................


public class Program12Main {

	public static void main(String[] args) {

			Child2 ch = new Child2();
			ch.show();
			ch.display();
			ch.display1();

		}

	}

