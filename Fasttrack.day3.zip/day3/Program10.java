package com.day3;

public abstract class Program10 {
	Program10(){
		System.out.println("Program10 Constructor Called..");
	}
	abstract void fun();
}
class Derived1 extends Program10{
	Derived1(){
		System.out.println("derived constructor Called..");
	}

	@Override
	void fun() {
		System.out.println("derived fun() Called..");
		
	}

}
