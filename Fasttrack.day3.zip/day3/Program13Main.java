package com.day3;

public class Program13Main {

	public static void main(String[] args) {
		Cats c = new Cats();
		c.eat1();
		c.meow();
		Dogs d1 = new Dogs(); //To access the Dogs class we have to create object for perticular class
		d1.bark();
	}
}
