package com.day3;

//hierarchical inheritance.................................

public class Program13 {//main class
	void eat1() {
		System.out.println("eating....");
	}

}
class Dogs extends Program13{    //child1 from main class
	void bark() {
		System.out.println("Barking....");
	}
}
class Cats extends Program13{     //child2 from main class
	void meow() {
		System.out.println("meowing.....");
	}
}