package com.day3;
import java.util.Scanner;
//if Statement

public class Program1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number: ");
		int a = sc.nextInt();
		if (a>0) {
			System.out.println("Positive");
		}
		sc.close();
	}

}
