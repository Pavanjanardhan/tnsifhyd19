package com.day3;

public class Program14Main {

	public static void main(String[] args) {
		Child ci = new Child();
		ci.show2();

	}

}
