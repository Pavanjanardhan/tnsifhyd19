package com.day3;
import java.util.Scanner;

//While loop....

public class Program5 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the value of i: ");
		int i = sc.nextInt();
		while (i<=10) {
			System.out.println(i);
			i++;
			sc.close();

		}
	
	}

}
