package com.day3;

public abstract class Program9 {
	abstract void fun();
}
class Derived extends Program9{

	void fun() {
		System.out.println("Derived fun() called..");
		
	}
	
	
}
