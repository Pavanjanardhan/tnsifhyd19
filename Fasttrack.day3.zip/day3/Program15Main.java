package com.day3;

public class Program15Main {
	
	public static void main(String[] args) {
		Program15 p1 = new Program15();
		p1.setDoors("Closed");
		p1.setEngine("on");
		p1.setDriver("seated");
		p1.setSpeed(100);
		System.out.println(p1.run());

	}

}
