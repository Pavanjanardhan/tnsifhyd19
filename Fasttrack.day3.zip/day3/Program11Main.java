package com.day3;

public class Program11Main {
	public static void main(String[] args) {
    	Dog d = new Dog();
		d.eat();
		d.bark();
}

}
