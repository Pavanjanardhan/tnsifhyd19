package com.day3;

//override...............................

public class Program14 {
	void show2() {
		System.out.println("parent show method..");
	}

}
class Child extends Program14{
	void show2() {
		System.out.println("child's show method..");
	}
}
