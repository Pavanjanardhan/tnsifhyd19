package com.day3;
import java.util.Scanner;

//Switch case Statement....

public class Program4 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the number: ");
		int num = sc.nextInt();
		switch (num) {
		case 10:
			System.out.println("the entered case value is : 10");
			break;
		case 20:
			System.out.println("the entered case value is : 20");
			break;
		case 30:
			System.out.println("the entered case value is : 30");
			break;
		case 40:
			System.out.println("the entered case value is : 40");
			break;
		case 50:
			System.out.println("the entered case value is : 50");
			break;
		default:System.out.println("not in any of these numbers.....");
			break;
		}
		sc.close();

	}

}
