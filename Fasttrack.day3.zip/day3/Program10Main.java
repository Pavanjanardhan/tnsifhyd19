package com.day3;

public class Program10Main {

	public static void main(String[] args) {
		Derived1 d = new Derived1();
		d.fun();
	}

}
