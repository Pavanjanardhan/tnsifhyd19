package com.day3;

//multilevel inheritance.........................

public class Program12 {
	void show() {
		System.out.println("Base class called..");
	}
}
class Child1 extends Program12 {
	void display() {
		System.out.println("Child 1 class called..");
	}
}
class Child2 extends Child1{
	void display1() {
		System.out.println("Child 2 class called..");
	}


}
