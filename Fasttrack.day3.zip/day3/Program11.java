package com.day3;

//single level inheritance....................................................

public class Program11 {
	void eat() {
		System.out.println("Eating  Base class method..");
	}
}
class Dog extends Program11{
	void bark() {
		System.out.println("Barking  child class method..");
	}

}
