package net.codejava;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UpdateData {

	public static void main(String[] args) {
		String dbURL = "jdbc:mysql://localhost:3306/database";
		String username = "root";
		String password = "pavan";
		 
		try {
		 
		    Connection conn = DriverManager.getConnection(dbURL, username, password);
		    String sql = "UPDATE Users SET password=?, fullname=?, email=? WHERE usernamel=?";
		    
		    PreparedStatement statement = conn.prepareStatement(sql);
		    statement.setString(1, "1542");
		    statement.setString(2, "Janardhan Pavan");
		    statement.setString(3, "pavan@google.com");
		    statement.setString(4, "111");
		     
		    int rowsUpdated = statement.executeUpdate();
		    if (rowsUpdated > 0) {
		        System.out.println("An existing user was updated successfully!");
		    }
		} catch (SQLException ex) {
		    ex.printStackTrace();
		}

	}

}
